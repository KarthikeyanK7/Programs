package encapsulation;

public class BaseEncap1 
{

	private String name; 	// actual variable
	private String id; 		// security purpose
	private int age; 		// class variable & also called global variable

	public int getAge() 
	{ 						// getter
		return age; 		// display somewhere
	}

	public String getName() 
	{
		return name;
	}

	public String getId() 
	{
		return id;
	}

	
	public void setAge(int newAge) 	// void- no return
	{ 								// setter method
		age = newAge;

	}

	public void setName(String newName) 
	{								// argument
		name = newName;
	}

	public void setId(String newId) 
	{
		id = newId;
	}

}