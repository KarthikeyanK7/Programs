package encapsulation;

public class BaseEncap2 
{
	
	private String email;
									//void----no return
	public String getEmail() 		//getter
	{							
		return email;
		//System.out.println(email);
		
	}

	public void setEmail(String email) //setter
	{
		this.email = email;
		//both argument and variable are same to differentiate here this keyword used.
	}

}