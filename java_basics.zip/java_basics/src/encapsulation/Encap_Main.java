package encapsulation;

public class Encap_Main {

	// class, method, object
	public static void main(String args[]) 
	{
		BaseEncap1 encap1 = new BaseEncap1();		// A,b,c,d,f,g,h,j,k----->m
		BaseEncap2 encap2 = new BaseEncap2();
		
		encap1.setName("James");//parameter passing
		encap1.setAge(20);
		encap1.setId("12343ms");

		encap2.setEmail("vrr456@gmail.com");	//passing the value to setter method

		System.out.print("Age : " + encap1.getAge() + "\nIDNUM  :" + encap1.getId() + "\nName :" + encap1.getName());
		System.out.println("\n");
		System.out.println("Mail-ID :"+encap2.getEmail());

		//System.out.println(encap1.age);//private variable can't access directly
	}

}