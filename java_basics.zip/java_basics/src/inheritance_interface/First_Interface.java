package inheritance_interface;

public interface First_Interface
{
	public void first();
}
