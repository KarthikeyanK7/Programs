package inheritance_interface;

public class IInher_Base implements IInf_three
{
	public void sum(int a) 
	{
		int mark1 = a, mark2 = 99;
		int total_Subject_Mark;
		total_Subject_Mark = mark1 + mark2;
		System.out.println(total_Subject_Mark);

	}

	@Override
	public void print() 
	{
		System.out.println("Interface");

		
	}
	public static void main(String[] args) 
	{
	Inher_Inface ii = new Inher_Inface();
		ii.sum(2);
		ii.calculate();
		ii.div();
		ii.print();
	}
	
}
