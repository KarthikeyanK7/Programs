package inheritance_interface;

//Inheritance_Interface

public class Inher_Inface extends IInher_Base implements IInf_one, IInf_two
{
	
	@Override
	public void calculate() 
	{
		int accbal = 400;
		int profit = 100;
		int expense;
		expense = accbal - profit;
		System.out.println(expense);
	}
	
	@Override
	public void div() 
	{
		System.out.println(100 / 10);

	}

}
 