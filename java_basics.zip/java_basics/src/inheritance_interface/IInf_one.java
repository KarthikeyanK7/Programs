package inheritance_interface;

public interface IInf_one 
{
	void calculate();
}
