package inheritance_interface;

public class Interface_Class implements First_Interface 
{
	@Override
	public void first() 
	{
		int a = 20;
		a = a * 5;
		System.out.println(a);
	}

	static void display() 
	{
		int a = 3000;
		System.out.println(a + 10);
	}

	void add() 
	{
		int a = 3000;
		System.out.println(a - 10);
	}

	
	public static void main(String[] args) 
	{
		Interface_Class inf = new Interface_Class();
		inf.first();
		inf.add();
		display();

	}
}
