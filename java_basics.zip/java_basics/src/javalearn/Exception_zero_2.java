package javalearn;

public class Exception_zero_2
{  
	  public static void main(String args[])
	  {  
	   try
	   {  
	      //code that may raise exception  
	      int data=100/0;
	      System.out.println(data);
	   }
	   
	   catch(ArithmeticException e)
	   {
		   System.out.println(e);
	   }  
	   
	  finally
	  {
		  System.out.println("rest of the code..."); 
		  //rest code of the program 
	  }
	   //no block
	   System.out.println("code in no block");
	   
	   // 1 2 3 4 5 6 7 8 9 10 ....
	  }  
	}  