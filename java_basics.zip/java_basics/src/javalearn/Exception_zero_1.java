package javalearn;

public class Exception_zero_1 
{
	public static void main(String args[]) 
	{
		try 
		{
			int a = 0;
			// code that may raise exception
			int data = 100 / 0;
			System.out.println(a+data);

		} 
		
		catch (ArithmeticException e) 
		{
			System.out.println("Division by zero " + e);
		}
		
		System.out.println("rest of the code...");
		
		// rest code of the program
		// no block
		
		System.out.println("code in no block");

		// 1 2 3 4 5 6 7 8 9 10 ....
	}
}