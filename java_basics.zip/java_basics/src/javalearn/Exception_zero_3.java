package javalearn;

public class Exception_zero_3{  
	  @SuppressWarnings("unused")
	public static void main(String args[]){  
	   try{  
		   String n="Five";
		   int n1=78;
		   int n2=96;
		 String  n3=n+n2;
		 System.out.println(n3);
		   int a=0;
	      //code that may raise exception  
	      int data=100/2; 
	      
	   }
	   catch(ArithmeticException e){
		   System.out.println("Division by zero "+e);
		   } 
	   finally {
	   System.out.println("rest of the code..."); 
	   //rest code of the program 
	   }
	   //no block
	   System.out.println("code in no block");
	   
	   // 1 2 3 4 5 6 7 8 9 10 ....11, 12
	  }  
	}  