package javalearn;

public class Variable_Types
{

	public static void main(String[] args) 
	{
		
		System.out.println("java using for selenium automation");

		// Variables in java 
		// Types-Primitive / Non Primitive
		// integer, Short, byte, long, Float, Double, Char, String, array
		int a = 2050571093;
		short b = 32767;
		byte c = 66;
		long ln = 9150571097878787878l;
		float fl = 1663453.0086f;
		double du = 1664444444666.3447777d;
		char employee_Type = 'q';
		String s = "java1234@#*%";//General variable

		System.out.println("A value = "+a);
		//+--joining operator or concat operator
		System.out.println(b);
		System.out.println(c);
		System.out.println(ln);
		System.out.println(fl);
		System.out.println(du);
		System.out.println(employee_Type);
		System.out.println(s);

	}

}
