package javalearn;

public class Advanced_For 
{
	public static void main(String[] args) 
	{
		int a[]= {1,2,3,4,5,6,7,8,9};
		for(int d:a) 
		{
			System.out.println(d);
		}		
	}
}
