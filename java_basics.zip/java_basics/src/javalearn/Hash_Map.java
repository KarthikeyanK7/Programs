package javalearn;

import java.util.HashMap;
import java.util.Map.Entry;

public class Hash_Map 
{

	public static void main(String[] args) 
	{
		HashMap<Integer,String> map=new HashMap<Integer,String>();
		map.put(1,"Mango");
		map.put(2,"Apple");
		map.put(3,"Pineapple");
		map.put(2,"Orange");
		map.put(5,"Apple");
		
		System.out.println("Itreating Hashmap...");
		for(Entry<Integer, String> m:map.entrySet())
		{
			System.out.println(m.getKey()+" "+m.getValue());
		}
		
	}

}
