package javalearn;

public class String_Functions {

	public static void main(String[] args) {
		// Ctrl+Shift+f-straight line
		System.out.println("Automation Testing");
		System.out.println("Selenium");

		System.out.println("\n");
		
		String FN = "jo";
		String MN = "haha";
		String LN = "nanus";
		// +-----concat(add) or Join

		String full_Name = FN + " " + MN + " " + LN;

		// space also one of the character in java

		System.out.println(full_Name);
		System.out.println("full name length is " + full_Name.length());

		String Name1 = "Ravi";
		String Name2 = "Kumar";
System.out.println(Name1.concat(Name2));//don't script like
		String Name = Name1 +" "+ Name2;
		System.out.println(Name);
		System.out.println(Name.length());// length starts from 1
		System.out.println("\n");
		

		String automation_Testing = "Selenium is Functional Testing Tool";
		System.out.println(automation_Testing.length());

		int a = 10, b = 20;

		int total_Mark = a + b;

		System.out.println(total_Mark);

		System.out.println("a & b added value = " + (a + b));

		char c = 't';

		System.out.println(c);

		String s = "Selenium";

		System.out.println("automation tool for functional testing is " + s);

		String firstname = "Parthasarathi";
		String lastname = "Shanmugam";
		String full_name = firstname + " " + lastname;

		System.out.println(firstname.length());// Starts from 1
		System.out.println(lastname.length());
		//System.out.println(firstname.concat(lastname));
		System.out.println(firstname + " " + lastname);//don't script like

		System.out.println(full_name);
		System.out.println(full_name.length());

		if (full_name.length() >= 3 && full_name.length() <= 36) {
			System.out.println("Your Name is " + full_name);
		} else {
			System.out.println("Name length minmum 3 and maximum 36");
		}
		
		
		
		
		

		String cc = "Sps @123# ";// General Data type
		int l = cc.length();
		System.out.println(l);

		String comment = "this is true and ";

		String result = "Truth one ";
		String result1 = "Truth one";

		boolean equal = result.equals(result1);// boolean-True or false statement
		char charAt = comment.charAt(11);// start from 0
		String cs = comment.concat(result);
		int indexOf = comment.indexOf("true");

		System.out.println(equal);
		System.out.println(charAt);
		System.out.println(cs);
		System.out.println(indexOf);

		System.out.println("join the strings : " + comment.concat(result));

		System.out.println(result.equals(result1));
		System.out.println(comment.length()); // count from 1
		System.out.println(comment.charAt(11));// count from 0
		System.out.println(comment.indexOf("true")); // count from 0

		String r = "DevOps Engineering";
		// reverse
		String rev = new StringBuffer(r).reverse().toString();
		System.out.println(rev);

		String revb = new StringBuilder(r).reverse().toString();
		System.out.println(revb);

	}

}
