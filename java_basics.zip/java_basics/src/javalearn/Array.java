package javalearn;

public class Array 
{
	int a[]={1,2,3,4,5,6,7,8,9};
	
	public void add()
	{
		for(int i=0;i<a.length;i++) 
		{
		System.out.println(a[i]+"\n");
		}
	}
	
	public static void main(String[] args) 
	{
		Array ar=new Array();
		ar.add();
	}
}
