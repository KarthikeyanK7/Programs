package javalearn;

public class String_Types 
{

	public static void main(String[] args) 
	{
		
		String s1="Java is programming language";
		String s2="Java is Programming Language";
		System.out.println(s1.length());
		
		
		//ctrl+2,l----->return type
		// finding string length
		int l = s1.length();// start from 1
		System.out.println(l);
		System.out.println("\n");
	
		
		//finding character position
		char cat = s2.charAt(17);//start from 0
		System.out.println(cat);
		//ctrl+2, l
		//finding both strings are equal
		boolean eql = s1.equals(s2);
		System.out.println(eql);
		
		
		//ignore case
		boolean eqlc = s1.equalsIgnoreCase(s2);
		System.out.println(eqlc);
		
		
		//finding Index value
		int iof=s1.indexOf('a');
		System.out.println(iof);
		
		
		//finding last index value
		int liof=s1.lastIndexOf('a');
		System.out.println(liof);
		System.out.println();
		String s3="Selenium is a Automation Tool";
		String s4="BECAUSE OF BECAUSE";
		
		
		//contains
		boolean con = s3.contains("Automation");
		System.out.println(con);
		
		
		//startswith
		boolean stawith=s3.startsWith("Selenium");
		System.out.println(stawith);
		
		
		//endswith
		boolean endwith=s3.endsWith("Tool");
		System.out.println(endwith);
		
		
		//ToUpperCase
		String uc = s3.toUpperCase();
		System.out.println(uc);
		
		
		//ToLowerCase
		String lc=s4.toLowerCase();
		System.out.println(lc);	
		System.out.println();	
		String s5=" ";
		
		
		//isempty
		boolean ise=s5.isEmpty();
		System.out.println(ise);
		String sss="Devops process and cloud technology";
		
		
		//substring
		String ss=sss.substring(19);
		System.out.println(ss);
		System.out.println("\n");
		
		
		//when,where,why,how,then,but
		String s55="When Enter 0 in a field the return must be 0 but the return mention not 0 it denote invalid value";
		
		
		//Split
		String w[] =s55.split(" ");
		int strlen = w.length;		
		System.out.println(strlen);		
		System.out.println("\n");		
		for (int i = 0; i < strlen; i++) 
		{			
			System.out.println(w[i]);
		}		
		System.out.println("\n");
		
		
		//trim
		String s6="-----API Testing-----";		
		int len=s6.length();		
		System.out.println(len);		
		System.out.println(s6);		
		String S6trim= s6.trim();		
		int len2=S6trim.length();
		System.out.println(len2);
		System.out.println(S6trim);		
		System.out.println("\n");		
		String s7="automation ";
		String s8="testing";
		
		
		//concat
		String cc=s7.concat(s8);
		System.out.println(cc);
		String s9="HTML  CSS   JAVASCRIPT";

		
		//Replace
		String rpl=s9.replace("HTML", "XML");
		System.out.println(rpl);	
				
	}

}
