package javalearn;

public class Exception_finally 
{

	public static void main(String[] args) 
	{
		// try, catch, throw or throws, finally, no block

		// 1 2 3 4 5 6 7 8 9 10 11

		// 1 2 3
		System.out.println("Above Try Block");
		int c = 50;
		System.out.println(c);

		// 4 5
		try 
		{
			int a[] = new int[3];
			a[0] = 77;
			a[1] = 89;
			a[2] = 109;
			System.out.println("Access element one :" + a[3]);
		}

		// 6 7 8 9 10
		finally 
		{
			System.out.println("finally block");
			int v = 10;
			System.out.println(v);
			int b = 20;
			System.out.println(b);

		}

		// no block
		// 11
		System.out.println("No Block Execution");

	}

}
