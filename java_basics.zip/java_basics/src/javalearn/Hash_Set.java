package javalearn;

import java.util.LinkedHashSet;
import java.util.Set;

public class Hash_Set 
{

	public static void main(String[] args) 
	{

		// Creating HashSet and adding elements
		Set<String> set = new LinkedHashSet<String>();
		// Treeset-ascending order
		// Hashset-Random order
		// LinkedHashset-insert order
		set.add("methods");
		set.add("inheritance");
		set.add("constructor");
		set.add("interface");
		set.add("abstract");
		set.add("abstract");

		System.out.println("value of set\n"+set+"\n");

		for(String h : set) 
		{
			System.out.println(h);
		}

		set.remove("interface");
		System.out.println("\nset values after remove");
		System.out.println(set);

		Set<String> set1 = new LinkedHashSet<String>();
		set1.add("Aggregation");
		set1.add("composition");
		set1.add("Association");
		set1.add("access modifier");
		set1.add("composition");
		set1.add("Association");

		System.out.println("\nValue of set1\n"+set1);
		set.addAll(set1);

		System.out.println("\nlist added after set1\n"+set);

		
	}

}
