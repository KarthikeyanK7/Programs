package javalearn;

public class Constructor 
{
	Constructor()//constructor name same as class name
	{ 
		System.out.println("constructor method");
	}
	
	void display() 
	{
		System.out.println("display method");
	}
	
	public static void main(String[] args) 
	{
		Constructor c=new Constructor();//default calling when object is cerated
		c.display();
	}
}
