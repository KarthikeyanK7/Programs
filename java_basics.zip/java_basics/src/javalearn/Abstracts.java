package javalearn;

abstract class one 
{												// base class
												// A,B,C->D
	void h1() 
	{											// normal method
		System.out.println("Normal Method");
	}

	abstract void h2();							// Interface method

}

public class Abstracts extends one 
{												// derived

	@Override
	void h2() 
	{
		System.out.println("implemented Abstract method in Derived class");

	}

	public static void main(String[] args) 
	{
		Abstracts a=new Abstracts();
		a.h1();
		a.h2();

	}
}
