package javalearn;

public class If_Else
{

	public static void main(String[] args) 
	{
		String a="true";
		if (a=="truee")
			System.out.println("ok");
		else
			System.out.println("no");
		

	}

}
