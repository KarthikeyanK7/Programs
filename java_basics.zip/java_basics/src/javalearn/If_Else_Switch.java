package javalearn;

public class If_Else_Switch
{

	public static void main(String[] args) 
	{
		// Parts of IF
		// value initialize, conditional part, iF Part, Else part
		// Types of IF
		// IF IF ELSE IF ELSE IF NESTED IF

		// if else-----------------------------------------------
		int m = 80;
		if (m >= 50) 
		{
			System.out.println("Pass Mark");
		} 
		else 
		{
			System.out.println("Fail Mark");
		}

		// else if-----------------------------------------------
		int mark = 60;

		if (mark >= 90) 
		{
			System.out.println("outstanding mark");
		}

		else if (mark >= 80) 
		{
			System.out.println("distinction mark");

		} 
		else if (mark >= 60) 
		{
			System.out.println("firstclass mark");
		} 
		else 
		{
			System.out.println("not elegible to join ");
		}

		/*
		 * int ten=88, twe=59, deg=87;
		 * 
		 * if(ten>=70) { if(twe>=70) { if(deg>=70) {
		 * System.out.println("Eligible to attend the interview"); }else {
		 * System.out.println("not eligible Because 10th mark less than 70%"); } else {
		 * System.out.println("not eligible Because 12th mark less than 70%"); } else {
		 * System.out.println("not eligible Because degree mark less than 70%"); } } }
		 */

		// nested if---------------------------------------------
		int age = 27;
		int weight = 58;

		if (age > 18) 
		{
			if (weight > 50) 
			{
				System.out.println("You are eligible to donate blood");
			} 
			else 
			{
				System.out.println("You are not eligible to donate blood");
			}
		} 
		else 
		{
			System.out.println("Age must be greater than 18");
		}

		
		//Switch-------------------------------------------------
		int days = 1;
		switch (days) 
		{
		case 1:
			System.out.println("Monday");
			break;
		case 2:
			System.out.println("Tuesday");
			break;
		case 3:
			System.out.println("Wednesday");
			break;
		case 4:
			System.out.println("Thursday");
			break;
		case 5:
			System.out.println("Friday");
			break;
		case 6:
			System.out.println("Saturday");
			break;
		case 7:
			System.out.println("Sunday");
			break;
		default:
			System.out.println("Enter the value between 1 to 7");
			break;

		}

		String c = "in";
		switch (c) 
		{
		case "in":
			System.out.println("india");
			break;
		case "us":
			System.out.println("united states");
			break;
		case "aus":
			System.out.println("australia");
			break;

		}

	}

}
