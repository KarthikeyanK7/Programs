package javalearn;

public class Array_Class {

	public static void main(String[] args) 
	{
		int total=583;
		int submarks[]= {98,99,100,97,96,93};
		for(int i=0;i<submarks.length;i++)
		{
			System.out.println(submarks[i]);
		}
		System.out.println(total);
		System.out.println("\n");
		
		
	}

}
