package javalearn;

public class Staticmethod 
{
	//static method execute only static variable
	//non static method execute both static and non static
	static int a=100,b=200,c;  
	int m=500;
	static void display()
	{
		c=a+b;
		System.out.println(c);
	}
	void print() 
	{
		System.out.println(m);
	}
	public static void main(String[] args) 
	{
		Staticmethod sm=new Staticmethod();
		sm.print();
		display();
		
	}

}
