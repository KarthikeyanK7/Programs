package numbers;

public class Number_Plate_code {
	private static int findDigitSum(int num) 
	{
		int digit, sum = 0;
		while (num != 0) 
		{
			digit = num % 10;
			sum = sum + digit;
			num = num / 10;
		}

		return sum;
	}

	public static void main(String[] args) 
	{
		int baseSum = 4 + 5 + 4 + 2 + 1 + 2; 	// TN 42 AK------numerology nos
		int luckyno = 7;						//lucky no

		System.out.println("Sum : " + luckyno + "\n");

		for (int i = 5000; i <= 6200; i++)  
		{
			int totalSum = 0;
			totalSum = baseSum + findDigitSum(i);

			while (totalSum > 9) 
			{
				totalSum = findDigitSum(totalSum);
			}

			if (totalSum == luckyno) 
			{
				System.out.println("TN 42 AK " + i);
			}
		}
	}
}
