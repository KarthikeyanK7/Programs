package numbers;

import java.util.Scanner;

public class Number_Plate
{
	
	static int findsum(int M)
	{	
		int n ,sum=0;
		while(M > 0)
		{
			n = M % 10;
			sum = sum + n;
			M = M / 10;
		}
		return sum;
	}
	
	static int findSums(int N) 
	{
		if (N < 10) 
			return N;

		int m,sums = 0;
		while (N > 0) 
		{
			m = N % 10;
			sums =sums + m;
			N = N / 10;
		}
		return findSums(sums);
	}

	public static void main(String[] args) 
	{
		//Change base for your current availability, this for 4500 to 5500
		
		//{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26};
		//{a,b,c,d,e,f,g,h,i,jj,kk,ll,mm,nn,oo,pp,qq,rr,ss,tt,uu,vv,ww,xx,yy,zz};
	
		int T=4;
		int N=5;
		int A=1;
		int K=2;
		int base = (T+N+4+2+A+K);
		int val = 0;
		Scanner s = new Scanner(System.in);
		System.out.print("Prefered number is ");
		int a = s.nextInt();
		
		System.out.println("----- TN 42 AK "+a+" -----");
		
		System.out.println("(TN 42 AK) sum = "+base);
		
		int id = findsum(a);
		System.out.println("("+a+") sum = "+id);
				
		int N1 = (base+id);
		System.out.println("(TN 42 AK) + ("+a+") = "+N1);

		int result = findsum(N1);
		
		System.out.println("("+N1+") sum = "+ result);
		
		if(result<10)
		{
			System.out.println("\n"+result);
		
		}
		else
		{
			val = findsum(result);
			System.out.println("\n"+val);
		}	
		s.close();
	
	}
	
}