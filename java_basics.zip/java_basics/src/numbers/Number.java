package numbers;

import java.util.Scanner;

public class Number 
{

	public static void main(String[] args) 
	{

		//String a[] = { "A","B","C","D","E","F","G","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z" };
		//String b= {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26};
		//String c= {a,b,c,d,e,f,g,h,i,jj,kk,ll,mm,nn,oo,pp,qq,rr,ss,tt,uu,vv,ww,xx,yy,zz};	
		//String c= {a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z};	
		//char c[]= {'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};
		
		int digit,base,sum = 0,n;
		int T=20;
		int N=14;
		int A=1;
		int K=11;
		base = (T+N+4+2+A+K);
		
		Scanner s=new Scanner(System.in);
		System.out.println("Print the 4 digit = TN 42 AK ");
		int a = s.nextInt();
		n=base+a;
		System.out.println(n);
		while(n > 0 || sum>9)  
		{  
			//finds the last digit of the given number
			digit = sum%10;
			//adds last digit to the variable sum
			sum = sum+digit;
			//removes the last digit from the number   
			sum = sum/10;
		}
		
		
		s.close();
	}
	
}
