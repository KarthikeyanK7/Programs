package PojoPack;

public class PojoA 
{
	private int price;
	
	public void Setter(int p)
	{
		price=p;
	}
	
	public int Getter()
	{
		return price;
	}

}
