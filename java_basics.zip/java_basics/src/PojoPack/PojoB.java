package PojoPack;

public class PojoB 
{
	public static void main(String[]args) 
	{
		PojoA p=new PojoA();
		p.Setter(123);
		System.out.println(p.Getter());
		p.Setter(321);
		System.out.println(p.Getter());
		p.Setter(456);
		System.out.println(p.Getter());	
	}

}
