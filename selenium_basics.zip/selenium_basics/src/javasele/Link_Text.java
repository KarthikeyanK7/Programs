package javasele;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Link_Text 
{

	public static void main(String[] args) throws Exception 
	{
		System.setProperty("webdriver.chrome.driver", "D:\\crmdriver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();

		driver.get("http://demo.guru99.com/test/link.html");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));

		// driver.findElement(By.xpath("//a[contains(@href,'fb.com')]")).click();
		driver.findElement(By.linkText("click here")).click();
		
		Thread.sleep(2000);
		driver.navigate().back();
		driver.findElement(By.partialLinkText("click here")).click();

		// Relative xpath using href
		Thread.sleep(2000);
		// Relative Xpath to select second link text
		driver.findElement(By.xpath("//*[contains(@href,'google.com')]")).click();
		driver.navigate().back();
		driver.findElement(By.xpath("//*[contains(@href,'fb.com')]")).click();
		driver.navigate().back();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//body/a[2]")).click();

		// a[@href='http://www.google.com']
		// a[@href='http://www.fb.com']

		Thread.sleep(2000);
		driver.findElement(By.xpath(" //a[@href='http://www.fb.com']")).click();
		Thread.sleep(2000);
		driver.navigate().back();

		Thread.sleep(2000);
		driver.quit();
		// Courses->BE,ME,MBA,MCA,MS
		// driver.findElement(By.xpath("//*[contains(@href,'fb.com')]")).click();
		// driver.findElement(By.xpath("//*[contains(@href,'fb.com')]")).click();
		// driver.findElement(By.xpath("//a[@href='http://www.fb.com/']")).click();

	}

}
