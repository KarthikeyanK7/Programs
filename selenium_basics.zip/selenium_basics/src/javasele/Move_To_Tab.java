package javasele;

import java.time.Duration;
import java.util.ArrayList;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Move_To_Tab
{

	public static void main(String[] args) throws InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver","D:\\crmdriver\\chromedriver.exe");	;
		WebDriver driver=new ChromeDriver();
		
		//get window handle is used to get the property of the window
		//window identification index=window property
		
		driver.get("https://www.seleniumeasy.com/test/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));

		
		((JavascriptExecutor)driver).executeScript("window.open()");
		ArrayList<String> tab2=new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tab2.get(1));
		Thread.sleep(2000);
		driver.get("https://www.google.com");
		Thread.sleep(2000);
		
		((JavascriptExecutor)driver).executeScript("window.open()");
		ArrayList<String> tab3=new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tab3.get(2));
		Thread.sleep(2000);
		driver.get("https://www.google.com");
		Thread.sleep(2000);
		driver.quit();
		
	}

}
