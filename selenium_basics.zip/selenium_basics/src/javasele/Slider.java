package javasele;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Slider 
{

	public static void main(String[] args) throws InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver", "D:\\crmdriver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		// IFrame & MainFrame
		driver.get("http://jqueryui.com/slider/");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));

		driver.switchTo().frame(0);     // frame(1) cause to find element error
		
		WebElement slider = driver.findElement(By.xpath("//span[contains(@class,'ui-slider-handle')]"));
		slider.click();   //span[contains(@class,'ui-slider')]
		Thread.sleep(2000);
		
		for(int i=1;i<=80;i++)
		{
			slider.sendKeys(Keys.ARROW_RIGHT);
		}
		Thread.sleep(5000);
		
		slider.click();
		
		for(int j=80;j>=30;j--)
		{
			slider.sendKeys(Keys.ARROW_LEFT);
		}
		Thread.sleep(2000);
		driver.quit();

	}
	
	
	/*	 driver.get("http://only-testing-blog.blogspot.in/2014/09/selectable.html");
	 Thread.sleep(5000); 
		
	 driver.manage().window().maximize();
	 WebElement sliderpoint = driver.findElement(By.cssSelector("#slider > span"));
	  Thread.sleep(5000); 
	
	  new Actions(driver).clickAndHold(sliderpoint).moveByOffset(500,0).release();

	  WebElement slider = driver.findElement(By.xpath("//*[@id=\"slider\"]/span"));
	    Actions move = new Actions(driver);
	    Action action = (Action) move.dragAndDropBy(slider, 30, 0).build();
	    ((Actions) action).perform();
}*/
	
}
