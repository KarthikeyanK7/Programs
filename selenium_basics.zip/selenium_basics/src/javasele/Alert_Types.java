package javasele;

import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Alert_Types 
{

	
	public static void main(String[] args) throws Exception 
	{

		System.setProperty("webdriver.chrome.driver","D:\\crmdriver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.get("http://www.leafground.com/pages/Alert.html");
		@SuppressWarnings("unused")
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
		
	//simple Alert
		driver.findElement(By.xpath("//button[text()='Alert Box']")).click();
		Thread.sleep(2000);
		//Interface(GP)<-Interface(P)<-Child class(2 level Upcasting)
		
		Alert alt=driver.switchTo().alert();
		System.out.println(alt.getText());
		alt.accept();
		Thread.sleep(2000);
		
	//confirm alert
		driver.findElement(By.xpath("//button[text()='Confirm Box']")).click();
		Thread.sleep(2000);
		driver.switchTo().alert().dismiss();
		Thread.sleep(2000);
		
	//Prompt Alert
		WebElement pa=driver.findElement(By.xpath("//button[text()='Prompt Box']"));
		pa.click();
	//Alert alt2 = wait.until(ExpectedConditions.alertIsPresent());
		Alert alt2=driver.switchTo().alert();
		alt2.sendKeys("mindtree");
		String at = alt2.getText();
		System.out.println(at);
		Thread.sleep(2000);
		alt2.accept();
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//button[text()='Line Breaks?']")).click();
		
		driver.switchTo().alert().accept();
		driver.quit();
		Thread.sleep(2000);
	}

}
