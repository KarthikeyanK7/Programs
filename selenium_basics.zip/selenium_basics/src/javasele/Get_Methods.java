package javasele;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Get_Methods 
{

	public static void main(String[] args) throws InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver", "D:\\crmdriver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));


		driver.get("https://www.amazon.in/");// method overloading | no browser history

		driver.navigate().to("https://www.flipkart.com/");// Browser history | method overriding

		driver.navigate().to("https://www.shopclues.com/");

		driver.navigate().back();
		Thread.sleep(3000);

		String currentUrl=driver.getCurrentUrl();   //get current url
		System.out.println(currentUrl);

		driver.navigate().back();
		Thread.sleep(3000);
		
		String pagesource=driver.getPageSource();   //get page source
		System.out.println(pagesource);
		
		driver.navigate().forward();
		Thread.sleep(3000);

		String title=driver.getTitle();
		System.out.println(title);          //get title

		driver.navigate().forward();
		Thread.sleep(3000);
		
		driver.quit();	
		
	}

}
