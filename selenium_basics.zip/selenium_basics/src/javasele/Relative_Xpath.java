package javasele;

import java.awt.AWTException;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Relative_Xpath 
{

	public static void main(String[] args) throws AWTException, InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver", "D:\\crmdriver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https:\\www.facebook.com");				
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));

		
		driver.findElement(By.xpath("//input[@type='text']")).sendKeys("admin"); 	//Relavite Xpath by Attribute Name
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@type='password']")).sendKeys("123654");
		Thread.sleep(3000);
		
		/*
		Robot r=new Robot();
		r.keyPress(KeyEvent.VK_ENTER);
		r.keyRelease(KeyEvent.VK_ENTER);		//or just we can find element of the login page and click
		//Thread.sleep(3000);
		*/
		driver.findElement(By.xpath("//button[@value='1']")).click();
		Thread.sleep(3000);
		//driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//div[@class='_9ai5']")).click();
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("//a[text()='Create a Page']")).click();				//Relavite Xpath by text (anchor tag)
		Thread.sleep(3000);											
		driver.navigate().back();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//a[text()='Forgotten password?']")).click();
		Thread.sleep(3000);
		
		driver.quit();
		
		
	}

}