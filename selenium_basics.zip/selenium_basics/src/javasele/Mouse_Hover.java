package javasele;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Mouse_Hover 
{

	public static void main(String[] args) throws InterruptedException 
	{
		 System.setProperty("webdriver.chrome.driver", "D:\\crmdriver\\chromedriver.exe");
		 WebDriver driver=new ChromeDriver();
		 driver.get("https://demoqa.com/menu/");
	     driver.manage().window().maximize();
	     driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));

	  	
	  	 Actions a = new Actions(driver);
	       
	     WebElement mainmenu = driver.findElement(By.xpath("//*[@id=\"nav\"]/li[2]/a"));
	     a.moveToElement(mainmenu).perform();
	     Thread.sleep(2000);
	    
	     WebElement subMenu = driver.findElement(By.xpath("//*[@id=\"nav\"]/li[2]/ul/li[3]/a")); 
	     a.moveToElement(subMenu).perform();
	     Thread.sleep(2000);
	    
	     WebElement SubMenuItem2 = driver.findElement(By.xpath("//*[@id=\"nav\"]/li[2]/ul/li[3]/ul/li[2]/a"));
	     SubMenuItem2.click();
	     driver.quit();
	 
	}

}
