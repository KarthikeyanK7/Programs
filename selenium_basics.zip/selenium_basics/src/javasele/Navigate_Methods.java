package javasele;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Navigate_Methods 
{

	public static void main(String[] args) throws InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver", "D:\\crmdriver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));


		// Page Navigation
		driver.get("https://www.amazon.in/");// method overloading | no browser history

		driver.navigate().to("https://www.flipkart.com/");// Browser history | method overriding

		driver.navigate().to("https://www.shopclues.com/");   //navigate to

		driver.navigate().back();   //navigate back
		Thread.sleep(3000);
		
		driver.navigate().refresh();   //navigate refresh

		driver.navigate().back();
		Thread.sleep(3000);
		
		driver.navigate().refresh();

		driver.navigate().forward();   //navigate forward
		Thread.sleep(3000);

		driver.navigate().refresh();

		driver.navigate().forward();
		Thread.sleep(3000);
		
		driver.quit();	
		
	}

}
