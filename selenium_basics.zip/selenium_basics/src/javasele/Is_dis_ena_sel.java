package javasele;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Is_dis_ena_sel {

	public static void main(String[] args) throws IOException, Exception  
	{
		System.setProperty("webdriver.chrome.driver", "D:\\crmdriver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		/*
		driver.get("http://brm.tremplintech.in/web_pages/login.aspx");
	
		//wait time in selenium
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
		driver.manage().window().maximize();	
		
		
		//   is Displayed ----- used to check whether the element is displayed in the screen
		
		WebElement user=driver.findElement(By.xpath("//input[@id='txt_unam']"));
		user.sendKeys("sylix");
		boolean udis=user.isDisplayed();
		System.out.println("Displayed ? "+udis);
		
		
		//   is Enabled ------ used to check whether the element is enabled or disabled  		
		
		WebElement pwd=driver.findElement(By.xpath("//input[@id='txt_pass']"));
		pwd.sendKeys("admin");
		boolean pena=pwd.isEnabled();
		System.out.println("Enabled ? "+pena);
		
		
		//  is Selected ------ check box, drop down, radio button
		//  used to check for buttons are selected or not
		
		boolean log=driver.findElement(By.xpath("//input[@id='Button3']")).isSelected();
		System.out.println("Selected ? "+log);
		Thread.sleep(2000);
		 */
		
//-------------------------------------------------------------------------------------------------------
		
		
		driver.get("https://demo.guru99.com/test/radio.html");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
		
		//Display
		boolean radio1dis=driver.findElement(By.xpath("//input[@id='vfb-7-1']")).isDisplayed();
		System.out.println("radio 1 - Displayed	= "+radio1dis);
		
		//Enable
		boolean radio2ena=driver.findElement(By.xpath("//input[@id='vfb-7-2']")).isEnabled();
		System.out.println("radio 2 - enabled	= "+radio2ena);
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//input[@id='vfb-7-2']")).click();
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//input[@id='vfb-7-3']")).click();
		Thread.sleep(2000);
		
//-------------------------------------------------------------------------------------------------------
		
		//Select
		WebElement check1= driver.findElement(By.xpath("//input[@id='vfb-6-0']"));
		check1.click();
		boolean check1sel=check1.isSelected();
		System.out.println("check 1 - Selected	= "+check1sel);
		Thread.sleep(2000);
		
		//Not Selected
		WebElement check2u= driver.findElement(By.xpath("//input[@id='vfb-6-0']"));
		check2u.click();
		boolean check2unsel=check2u.isSelected();
		System.out.println("check 1 - selected	= "+check2unsel+"	= so not selected");
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//input[@id='vfb-6-1']")).click();
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//input[@id='vfb-6-1']")).click();
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//input[@id='vfb-6-1']")).click();
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//input[@id='vfb-6-2']")).click();
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//input[@id='vfb-6-0']")).click();
		Thread.sleep(2000);
		
		
		driver.quit();
	
	}
}