package javasele;

import java.time.Duration;
//import java.sql.Driver;
//import java.text.ParseException;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


public class Web_Table 
{

	
	public static void main(String[] args) //throws ParseException, InterruptedException 
	{
	
		System.setProperty("webdriver.chrome.driver","D:\\crmdriver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://demo.guru99.com/test/web-table-element.php");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
		
		
		List<WebElement> rows = driver.findElements(By.tagName("tr"));
		int rowcount=rows.size();
		System.out.println("row count = "+rowcount);			//row size
		
		
		List<WebElement> columns = driver.findElements(By.tagName("th"));
		//int columncount=columns.size();
		//System.out.println("column count = "+columncount);
		System.out.println("column count = "+columns.size()); //column size
		
		
		for(WebElement heading:columns)						
		{
			String headings=heading.getText();
			System.out.print(headings+"\t");		//print - heading row
		}
		System.out.println("\n");
		
		
//		List<WebElement> alldata = driver.findElements(By.xpath("//table[@class='dataTable']/tbody"));		
//		for(WebElement datas:alldata)
//		{
//			String a=datas.getText();
//			System.out.print(a+"\t");				//print - all data
//		}
//		System.out.println("\n");
		
		List<WebElement> data = driver.findElements(By.xpath("//table[@class='dataTable']/tbody/tr[1]/td"));
		for(WebElement datas:data)
		{
			String b=datas.getText();
			System.out.print(b+"\t");				//print - first row
		}
	
		System.out.println("\n");
		
		WebElement singledata = driver.findElement(By.xpath("//table[@class='dataTable']/tbody/tr[4]/td[1]"));
		System.out.println(singledata.getText());	//print - particular cell
		System.out.println("\n");
		
		
//		for(int i=0;i<data.size();i++)				//other for loop for printing
//		{
//			System.out.print(data.get(i).getText());
//		}

		driver.quit();
	}
}
