package javasele;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Drag_Drop 
{

	public static void main(String[] args) throws InterruptedException 
	{

		System.setProperty("webdriver.chrome.driver","D:\\crmdriver\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("http://demo.guru99.com/test/drag_drop.html");	
		driver.manage().window().maximize();			
         		    		
	        WebElement From=driver.findElement(By.xpath("/html/body/section/div/div/main/div/div/div/div/div/div/div[1]/div/ul/li[5]/a"));	
	        	   		
	         WebElement To=driver.findElement(By.xpath("//*[@id=\"bank\"]/li"));
	        	         		        		
	         Actions a=new Actions(driver);					

			 a.dragAndDrop(From, To).build().perform();
			 	
			 Thread.sleep(2000);
			 			 	 	 		     
	         WebElement obj5000=driver.findElement(By.xpath("//*[@id=\"fourth\"]/a"));
	        	        
	         Thread.sleep(2000);
	         WebElement placehold1=driver.findElement(By.xpath(" //*[@id=\"amt7\"]/li"));
	         WebElement placehold2=driver.findElement(By.xpath("//*[@id=\"amt8\"]/li"));	          
	         
	         a.dragAndDrop(obj5000, placehold1).build().perform();
	         Thread.sleep(2000);
	         a.dragAndDrop(obj5000, placehold2).build().perform();
	         Thread.sleep(2000);
	         
	         WebElement sales = driver.findElement(By.xpath("//*[@id=\"credit1\"]/a"));
	         WebElement salesplaceholer = driver.findElement(By.xpath("//*[@id=\"loan\"]/li"));
	         Thread.sleep(2000);
	         a.dragAndDrop(sales, salesplaceholer).build().perform();
	         Thread.sleep(2000);
	         driver.close();

	}

}
