package javasele;

import java.io.IOException;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class AAA 
{

	
	public static void main(String[] args) throws IOException, Exception  
	{
		System.setProperty("webdriver.chrome.driver", "D:\\crmdriver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://brm.tremplintech.in/web_pages/login.aspx");
		//wait time in selenium
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
		//Thread.sleep(5000);
		driver.manage().window().maximize();	
		
		
		//   is Displayed ----- used to check whether the element is displayed in the screen
		
		WebElement user=driver.findElement(By.xpath("//input[@id='txt_unam']"));
		user.sendKeys("sylix");
		boolean udis=user.isDisplayed();
		System.out.println("Displayed ? "+udis);
		
		
		//   is Enabled ------ used to check whether the element is enabled or disabled  		
		
		WebElement pwd=driver.findElement(By.xpath("//input[@id='txt_pass']"));
		pwd.sendKeys("admin");
		boolean pena=pwd.isEnabled();
		System.out.println("Enabled ? "+pena);
		
		
		//  is Selected ------ check box, drop down, radio button
		//  used to check for buttons are selected or not
		
		boolean log=driver.findElement(By.xpath("//input[@id='Button3']")).isSelected();
		System.out.println("Selected ? "+log);
		Thread.sleep(2000);
		driver.quit();
}
}