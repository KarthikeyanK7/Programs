package javasele;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class Data_Driven 
{

	public static void main(String[] args) throws BiffException, IOException, InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver","D:\\crmdriver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://brm.tremplintech.in/web_pages/ord_reg.aspx");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));

		// JXL or POI
		// take file-> get workbook->mention sheet->track row-->Read Cell value
		FileInputStream f = new FileInputStream("C:\\Users\\karth\\eclipse-workspace\\javabasic\\javasele\\xlfiles\\brmexceldata.xls");
		Workbook b = Workbook.getWorkbook(f);
		Sheet s = b.getSheet(0);
		int rowcount = s.getRows();
		
		System.out.println("No. of rows = "+ rowcount);
	
		for (int i = 1; i < rowcount; i++) 
		{
			// (col,row) 0,1 1,1 | 0,2 1,2 | 0,3 1,3
			String username = s.getCell(0, i).getContents();
			String password = s.getCell(1, i).getContents();
			System.out.println("Username"+ i+" = "+username+"\n"+"Password"+ i+" = "+password);

			driver.findElement(By.xpath("//input[@id='txt_unam']")).sendKeys(username);
			driver.findElement(By.xpath("//input[@id='txt_pass']")).sendKeys(password);
			driver.findElement(By.xpath("//input[@id='Button3']")).click();
			Thread.sleep(1000);
			driver.findElement(By.xpath("//a[@id='LinkButton1']")).click();
			
		//	driver.switchTo().alert().accept();
			

		}
		
		driver.quit();

	}

}
