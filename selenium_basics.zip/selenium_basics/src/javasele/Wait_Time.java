package javasele;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Wait_Time {

	@SuppressWarnings("deprecation")
	public static void main(String[] args) 
	{

		System.setProperty("webdriver.chrome.driver","D:\\crmdriver\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		String UploadURL = "http://demo.guru99.com/test/upload/";   	//Types of Wait Time
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));

       
        driver.get(UploadURL);  //5  8  12
        
        //Explicit Wait
        //Thread.sleep(30000);//screenshot
        
       // Implicitwait
       driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);//execution wait
       driver.close();
	}

}