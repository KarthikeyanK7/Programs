package javasele;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class FindElement_Methods        //  By - id, name, x path ; accept()
{
	

	public static void main(String[] args) throws InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver","D:\\crmdriver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://www.brm.tremplintech.in/web_pages/login.aspx");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.findElement(By.xpath("//input[@id='txt_unam']")).sendKeys("sylix");
		//Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@id='txt_pass']")).sendKeys("admin");
		//Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@id='Button3']")).click();
		//Thread.sleep(2000);
		driver.findElement(By.xpath("//a[@id='LinkButton1']")).click();
		//or
		//driver.findElement(By.linkText("LOGOUT")).click();
		//Thread.sleep(2000);
		System.out.println("Logged in successfully");
		
		//driver.switchTo().alert().accept();		//when password is false
		//Thread.sleep(1000);
		

				/*
				 
				 //WebElement Concept
		
				WebElement user = driver.findElement(By.xpath("//input[@id='txt_unam']"));
				user.sendKeys("sylix");
				
				WebElement pass = driver.findElement(By.xpath("//input[@id='txt_pass']"));
				pass.sendKeys("admin");
			
				WebElement login = driver.findElement(By.xpath("//input[@id='Button3']"));
				login.click();
					
				WebElement logout = driver.findElement(By.xpath("//input[@id='Button3']"));
				logout.click();
			
				//WebElement logout = driver.findElement(By.linkText("LOGOUT"));
				//logout.click(); 
				 
				 */
			
				
				
		driver.quit();
	}
	
}