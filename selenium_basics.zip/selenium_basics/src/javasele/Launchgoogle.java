package javasele;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

//import net.bytebuddy.dynamic.loading.ClassInjector.UsingJna.Dispatcher.Windows32BitFunctionMapper;

public class Launchgoogle 
{
	public static void main(String[] args) throws InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver","D:\\crmdriver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.google.co.in/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
		System.out.println(driver.getTitle());
		driver.findElement(By.xpath("//input[@name='q']")).sendKeys("selenium" + Keys.ENTER);
		Thread.sleep(2000);
		System.out.println(driver.getTitle());
		driver.findElement(By.xpath("//h3[text()='Selenium']")).click();
		Thread.sleep(2000);
		System.out.println(driver.getTitle());
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("window.scrollBy(0,850)");
		driver.findElement(By.xpath("//a[@class='selenium-button selenium-ide text-uppercase font-weight-bold']")).click();
		System.out.println(driver.getTitle());
		driver.navigate().back();
		Thread.sleep(2000);
		driver.get("https://www.javatpoint.com/java-tutorial");
		//driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
		System.out.println(driver.getTitle());
		driver.findElement(By.xpath("//a[text()='Test it Now']")).click();
		List<String> windowhandles=new ArrayList<String>(driver.getWindowHandles()); 
		driver.switchTo().window(windowhandles.get(1));
		System.out.println(driver.getTitle());
		driver.findElement(By.xpath("//input[@id='bt2']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//a[text()='JavaTpoint.com']")).click();
		Thread.sleep(2000);
		driver.close();
		driver.switchTo().window(windowhandles.get(0));
		driver.navigate().to("https://www.flipkart.com/");
		System.out.println(driver.getTitle());		
		driver.findElement(By.xpath("//button[text()='✕']"));
		Thread.sleep(2000);	
		driver.findElement(By.xpath("//input[contains(@placeholder,'Search for products')]")).sendKeys("mobiles");
		System.out.println(driver.getTitle());
		
		
		
		
		driver.quit();
		
			
		
		//driver.quit();
		
	}//div[text()='See more']
}
