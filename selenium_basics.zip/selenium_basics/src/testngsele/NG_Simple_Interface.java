package testngsele;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;

public class NG_Simple_Interface implements Valid_Interface 
{
	WebDriver driver;

	@Test(priority = 5)						  
	@Override				//Method for Valid_Interface						
	public void valid() throws InterruptedException 
	{

		WebElement user = driver.findElement(By.xpath("//input[@id='txt_unam']"));
		user.sendKeys("sylix");
		WebElement pwd = driver.findElement(By.xpath("//input[@id='txt_pass']"));
		pwd.sendKeys("admin");
		WebElement Login = driver.findElement(By.xpath("//input[@id='Button3']"));
		Login.click();
		System.out.println("5 interface");
		Thread.sleep(1000);
		WebElement logout = driver.findElement(By.xpath("//a[@id='LinkButton1']"));
		logout.click();
		

	}

	@Test(priority = 4)
	public void fvalid() throws InterruptedException 
	{

		WebElement user = driver.findElement(By.xpath("//input[@id='txt_unam']"));
		user.sendKeys("sylix");
		WebElement pwd = driver.findElement(By.xpath("//input[@id='txt_pass']"));
		pwd.sendKeys("admin");
		WebElement Login = driver.findElement(By.xpath("//input[@id='Button3']"));
		Login.click();
		System.out.println("4");
		WebElement logout = driver.findElement(By.xpath("//a[@id='LinkButton1']"));
		logout.click();

	}

	@Test(priority = 2)
	public void finvalid() throws InterruptedException 
	{

		WebElement user = driver.findElement(By.xpath("//input[@id='txt_unam']"));
		user.sendKeys("syli6");
		WebElement pwd = driver.findElement(By.xpath("//input[@id='txt_pass']"));
		pwd.sendKeys("admi9");
		WebElement Login = driver.findElement(By.xpath("//input[@id='Button3']"));
		Login.click();
		Thread.sleep(1000);
		System.out.println("2");
		driver.switchTo().alert().accept();

	}

	@Test(priority = 3)
	public void fillegal() throws InterruptedException 
	{

		WebElement user = driver.findElement(By.xpath("//input[@id='txt_unam']"));
		user.sendKeys("s$lix");
		WebElement pwd = driver.findElement(By.xpath("//input[@id='txt_pass']"));
		pwd.sendKeys("admi#");
		WebElement Login = driver.findElement(By.xpath("//input[@id='Button3']"));
		Login.click();
		Thread.sleep(1000);
		System.out.println("3");
		driver.switchTo().alert().accept();

	}

	@Test(priority = 1)
	public void fnull() throws InterruptedException 
	{

		WebElement user = driver.findElement(By.xpath("//input[@id='txt_unam']"));
		user.sendKeys(" ");
		WebElement pwd = driver.findElement(By.xpath("//input[@id='txt_pass']"));
		pwd.sendKeys(" ");
		WebElement Login = driver.findElement(By.xpath("//input[@id='Button3']"));
		Login.click();
		Thread.sleep(1000);
		System.out.println("1");
		driver.switchTo().alert().accept();

	}

	@BeforeClass
	public void beforeClass() throws InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver","D:\\crmdriver\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://brm.tremplintech.in/web_pages/login.aspx");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

	}

	@AfterClass
	public void afterClass() throws InterruptedException 
	{
		driver.quit();
		
	}

}
