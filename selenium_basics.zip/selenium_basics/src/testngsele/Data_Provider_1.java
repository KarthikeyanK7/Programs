package testngsele;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class Data_Provider_1 
{
	public static WebDriver driver;

	@Test(dataProvider = "passing")
	public  void brm(String username,String password ) throws InterruptedException 
	{
		driver.findElement(By.xpath("//input[@id='txt_unam']")).sendKeys(username);
		driver.findElement(By.xpath("//input[@id='txt_pass']")).sendKeys(password);
		driver.findElement(By.xpath("//input[@id='Button3']")).click();
		
		WebElement logout = driver.findElement(By.xpath("//a[@id='LinkButton1']"));
		boolean dis = logout.isDisplayed();
		
		String s1 = String.valueOf(dis);
		
		if(s1 == "true")
		{
			logout.click();
			Thread.sleep(2000);
		}
		else
		{	
			driver.switchTo().alert().accept();
			Thread.sleep(2000);
		}
		Thread.sleep(2000);
		
	}
	
	
	@DataProvider
	public Object[][] passing()
	{
		return new Object[][]
				{
					{"sylix","admin"},
					{"sylix","sylix"},
					{"admin","admin"},
					{"sylix","admin"}
				};
	}


	@BeforeClass
	public void beforeClass() throws InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver", "D:\\crmdriver\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://brm.tremplintech.in/web_pages/login.aspx");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	}

	@AfterClass
	public void afterClass() 
	{
		driver.close();
	}

}
