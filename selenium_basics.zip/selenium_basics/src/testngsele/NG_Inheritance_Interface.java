package testngsele;

/*import java.time.Duration;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Ignore;*/
import org.testng.annotations.Test;
import org.openqa.selenium.By;

public class NG_Inheritance_Interface extends NG_Interface implements A_Interface, B_Interface, C_Interface 
{
	//public WebDriver driver;
	
	
	@Test(priority=8)
	@Override
	public void c_interface_null() throws InterruptedException 
	{
		driver.findElement(By.xpath("//input[@id='txt_unam']")).sendKeys("sylix12");
		driver.findElement(By.xpath("//input[@id='txt_pass']")).sendKeys("ada5min");
		driver.findElement(By.xpath("//input[@id='Button3']")).click();
		Thread.sleep(1000);
		System.out.println("InI-c-null");
		driver.switchTo().alert().accept();	
		
	}
	
	@Test(priority=7)
	@Override
	public void b_interface_illegal() throws InterruptedException {
		driver.findElement(By.xpath("//input[@id='txt_unam']")).sendKeys("$ylix");
		driver.findElement(By.xpath("//input[@id='txt_pass']")).sendKeys("@dmin");
		driver.findElement(By.xpath("//input[@id='Button3']")).click();
		Thread.sleep(1000);
		System.out.println("InI-b-illegal");
		driver.switchTo().alert().accept();	
		
	}
	
	@Test(priority=5)
	@Override
	public void a_interface_valid() throws InterruptedException {
		driver.findElement(By.xpath("//input[@id='txt_unam']")).sendKeys("sylix");
		driver.findElement(By.xpath("//input[@id='txt_pass']")).sendKeys("admin");
		driver.findElement(By.xpath("//input[@id='Button3']")).click();
		Thread.sleep(1000);
		System.out.println("InI-a-valid");
		driver.findElement(By.xpath("//a[@id='LinkButton1']")).click();
		
		
	}
	
	@Test(priority=6)
	@Override
	public void a_interface_invalid() throws InterruptedException {
		driver.findElement(By.xpath("//input[@id='txt_unam']")).sendKeys("sss");
		driver.findElement(By.xpath("//input[@id='txt_pass']")).sendKeys("admin");
		driver.findElement(By.xpath("//input[@id='Button3']")).click();
		Thread.sleep(1000);
		System.out.println("InI-a-invalid");
		driver.switchTo().alert().accept();		
		
	}
	
	@Test(priority = 1)
	public void ii_valid() throws InterruptedException {

		driver.findElement(By.xpath("//input[@id='txt_unam']")).sendKeys("sss");
		driver.findElement(By.xpath("//input[@id='txt_pass']")).sendKeys("admin");
		driver.findElement(By.xpath("//input[@id='Button3']")).click();
		Thread.sleep(1000);
		System.out.println("InI-valid");
		driver.switchTo().alert().accept();

	}

	@Test(priority = 2)
	public void ii_invalid() throws InterruptedException {

		driver.findElement(By.xpath("//input[@id='txt_unam']")).sendKeys("sylix123");
		driver.findElement(By.xpath("//input[@id='txt_pass']")).sendKeys("admin456");
		driver.findElement(By.xpath("//input[@id='Button3']")).click();
		Thread.sleep(1000);
		System.out.println("InI-invalid");
		driver.switchTo().alert().accept();
	}
	
	//@Ignore
	@Test(invocationCount=2)
	public void ii_invaliding() throws InterruptedException {

		driver.findElement(By.xpath("//input[@id='txt_unam']")).sendKeys("sylix123");
		driver.findElement(By.xpath("//input[@id='txt_pass']")).sendKeys("admin456");
		driver.findElement(By.xpath("//input[@id='Button3']")).click();
		Thread.sleep(1000);
		System.out.println("InI-cinvaliding");
		driver.switchTo().alert().accept();
	}

	
	@Test(priority = 3)
	public void ii_illegal() throws InterruptedException {

		driver.findElement(By.xpath("//input[@id='txt_unam']")).sendKeys("@#$");
		driver.findElement(By.xpath("//input[@id='txt_pass']")).sendKeys("@#$");
		driver.findElement(By.xpath("//input[@id='Button3']")).click();
		Thread.sleep(1000);
		System.out.println("InI-illegal");
		driver.switchTo().alert().accept();

	}
	
	@Test(priority = 4)
	public void ii_null() throws InterruptedException {

		driver.findElement(By.xpath("//input[@id='txt_unam']")).sendKeys(" ");
		driver.findElement(By.xpath("//input[@id='txt_pass']")).sendKeys(" ");
		driver.findElement(By.xpath("//input[@id='Button3']")).click();
		Thread.sleep(1000);
		System.out.println("InI-null");
		driver.switchTo().alert().accept();

	}

	/*
	@BeforeClass
	public void beforeClass() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","D:\\Crmdriver\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.navigate().to("http://brm.tremplintech.in/web_pages/login.aspx");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));


	}

	@AfterClass	//(alwaysRun=true)
	public void afterClass() throws InterruptedException {
		
		driver.quit();
		Thread.sleep(1000);
	}
	*/
	
}