package testngsele;

public interface C_Interface 
{
	void c_interface_null() throws InterruptedException;

}
