package testngsele;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

//Different Sheet in same XL for Data Driven in TestNG:

public class NG_DD_DS_SXL 
{
	WebDriver driver;
	String xlpath = "D:\\Study Docs\\Files\\ng_dd_ds_sxl.xls";

	@Test(priority = 1)
	public void DD_valid() throws BiffException, IOException, InterruptedException 
	{
		FileInputStream f = new FileInputStream(xlpath);
		Workbook b = Workbook.getWorkbook(f);
		Sheet s = b.getSheet(0);		
		// int rowcount =s.getRows();		//if u want to print the entire data present in xl
		for (int i = 1; i < 4; i++) 
		{
			String username = s.getCell(0, i).getContents();
			String password = s.getCell(1, i).getContents();
			
			driver.findElement(By.xpath("//input[@id='txt_unam']")).sendKeys(username);
			driver.findElement(By.xpath("//input[@id='txt_pass']")).sendKeys(password);
			driver.findElement(By.xpath("//input[@id='Button3']")).click();
			Thread.sleep(1000);
			System.out.println("USERNAME = "+username+"\nPASSWORD = "+password);
			driver.findElement(By.xpath("//a[@id='LinkButton1']")).click();
	
		}
		System.out.println();

	}

	@Test(priority = 2)
	public void DD_invalid() throws BiffException, IOException, InterruptedException 
	{
		FileInputStream f = new FileInputStream(xlpath);
		Workbook b = Workbook.getWorkbook(f);
		Sheet s = b.getSheet(1);
		// int rowcount =s.getRows();
		for (int i = 4; i < 7; i++) 
		{
			String username = s.getCell(0, i).getContents();
			String password = s.getCell(1, i).getContents();

			driver.findElement(By.xpath("//input[@id='txt_unam']")).sendKeys(username);
			driver.findElement(By.xpath("//input[@id='txt_pass']")).sendKeys(password);
			driver.findElement(By.xpath("//input[@id='Button3']")).click();
			Thread.sleep(1000);
			System.out.println("USERNAME = "+username+"\nPASSWORD = "+password);
			driver.switchTo().alert().accept();
		}
		System.out.println();
		
	}
	
	@Test(priority = 3)
	public void DD_illegal() throws BiffException, IOException, InterruptedException 
	{
		FileInputStream f = new FileInputStream(xlpath);
		Workbook b = Workbook.getWorkbook(f);
		Sheet s = b.getSheet(2);
		// int rowcount =s.getRows();
		for (int i = 7; i < 10; i++) 
		{
			String username = s.getCell(0, i).getContents();
			String password = s.getCell(1, i).getContents();

			driver.findElement(By.xpath("//input[@id='txt_unam']")).sendKeys(username);
			driver.findElement(By.xpath("//input[@id='txt_pass']")).sendKeys(password);
			driver.findElement(By.xpath("//input[@id='Button3']")).click();
			Thread.sleep(1000);
			System.out.println("USERNAME = "+username+"\nPASSWORD = "+password);
			driver.switchTo().alert().accept();
		}
		System.out.println();

	}
	
	@Test(priority =4)
	public void DD_null() throws BiffException, IOException, InterruptedException 
	{
		FileInputStream f = new FileInputStream(xlpath);
		Workbook b = Workbook.getWorkbook(f);
		Sheet s = b.getSheet(3);
		int rowcount =s.getRows();
		for (int i = 9; i < rowcount ; i++) 
		{
			String username = s.getCell(0, i).getContents();
			String password = s.getCell(1, i).getContents();

			driver.findElement(By.xpath("//input[@id='txt_unam']")).sendKeys(username);
			driver.findElement(By.xpath("//input[@id='txt_pass']")).sendKeys(password);
			driver.findElement(By.xpath("//input[@id='Button3']")).click();
			Thread.sleep(1000);
			System.out.println("USERNAME = "+username+"\nPASSWORD = "+password);
			driver.switchTo().alert().accept();
		}
		System.out.println();

	}

	@BeforeClass
	public void beforeClass() throws InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver","D:\\crmdriver\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://brm.tremplintech.in/web_pages/login.aspx");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	}

	@AfterClass
	public void afterClass() throws InterruptedException
	{
		
		driver.close();
		Thread.sleep(1000);
	}

}