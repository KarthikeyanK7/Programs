package testngsele;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;

public class NG_Enabled_alwaysRun 		//alwaysrun=true--->enabled=true--->invocationcount--->priority
{
	WebDriver driver;

	@Test(invocationCount = 2,invocationTimeOut = 30000)			//invocation count
	public void invocation() throws InterruptedException
	{
		driver.findElement(By.xpath("//input[@id='txt_unam']")).sendKeys("sylix");
		driver.findElement(By.xpath("//input[@id='txt_pass']")).sendKeys("admin");
		driver.findElement(By.xpath("//input[@id='Button3']")).click();
		Thread.sleep(1000);
		System.out.println("invocation count");
		driver.findElement(By.xpath("//a[@id='LinkButton1']")).click();
		
	}
	
	@Test(priority = 5)						  
	public void priority_m()
	{

		WebElement user = driver.findElement(By.xpath("//input[@id='txt_unam']"));
		user.sendKeys("sylix");
		WebElement pwd = driver.findElement(By.xpath("//input[@id='txt_pass']"));
		pwd.sendKeys("admin");
		WebElement Login = driver.findElement(By.xpath("//input[@id='Button3']"));
		Login.click();
		System.out.println("priority");
		WebElement logout = driver.findElement(By.xpath("//a[@id='LinkButton1']"));
		logout.click();
		

	}
	@Test(enabled = true)
	public void enabled_true_m() 
	{

		WebElement user = driver.findElement(By.xpath("//input[@id='txt_unam']"));
		user.sendKeys("syli6");
		WebElement pwd = driver.findElement(By.xpath("//input[@id='txt_pass']"));
		pwd.sendKeys("admi9");
		WebElement Login = driver.findElement(By.xpath("//input[@id='Button3']"));
		Login.click();
		System.out.println("enabled = true");
		driver.switchTo().alert().accept();

	}

	@Test(enabled = false)
	public void enabled_false_m()
	{

		WebElement user = driver.findElement(By.xpath("//input[@id='txt_unam']"));
		user.sendKeys("sylix");
		WebElement pwd = driver.findElement(By.xpath("//input[@id='txt_pass']"));
		pwd.sendKeys("admin");
		WebElement Login = driver.findElement(By.xpath("//input[@id='Button3']"));
		Login.click();
		System.out.println("enabled = false");
		WebElement logout = driver.findElement(By.xpath("//a[@id='LinkButton1']"));
		logout.click();

	}

	@Test(alwaysRun = true)
	public void always_run_true_m() 
	{

		WebElement user = driver.findElement(By.xpath("//input[@id='txt_unam']"));
		user.sendKeys("syli6");
		WebElement pwd = driver.findElement(By.xpath("//input[@id='txt_pass']"));
		pwd.sendKeys("admi9");
		WebElement Login = driver.findElement(By.xpath("//input[@id='Button3']"));
		Login.click();
		System.out.println("always run = true");
		driver.switchTo().alert().accept();

	}

	@Test(enabled=true , alwaysRun=false)
	public void enabled_true_always_run_false() 
	{

		WebElement user = driver.findElement(By.xpath("//input[@id='txt_unam']"));
		user.sendKeys("s$lix");
		WebElement pwd = driver.findElement(By.xpath("//input[@id='txt_pass']"));
		pwd.sendKeys("admi#");
		WebElement Login = driver.findElement(By.xpath("//input[@id='Button3']"));
		Login.click();
		System.out.println("enabled = true , always run = false");
		driver.switchTo().alert().accept();

	}

	@Test(enabled=false, alwaysRun=true)
	public void enabled_false_always_run_true() 
	{

		WebElement user = driver.findElement(By.xpath("//input[@id='txt_unam']"));
		user.sendKeys(" ");
		WebElement pwd = driver.findElement(By.xpath("//input[@id='txt_pass']"));
		pwd.sendKeys(" ");
		WebElement Login = driver.findElement(By.xpath("//input[@id='Button3']"));
		Login.click();
		System.out.println("enebled = false , always run = true");
		driver.switchTo().alert().accept();

	}
	
	@Test(enabled=true, alwaysRun=true)
	public void enabled_true_alwaysRun_true() 
	{

		WebElement user = driver.findElement(By.xpath("//input[@id='txt_unam']"));
		user.sendKeys(" ");
		WebElement pwd = driver.findElement(By.xpath("//input[@id='txt_pass']"));
		pwd.sendKeys(" ");
		WebElement Login = driver.findElement(By.xpath("//input[@id='Button3']"));
		Login.click();
		System.out.println("enebled = true , always run = true");
		driver.switchTo().alert().accept();

	}


	@BeforeClass
	public void beforeClass() throws InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver","D:\\crmdriver\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://brm.tremplintech.in/web_pages/login.aspx");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

	}

	@AfterClass
	public void afterClass() throws InterruptedException 
	{
		
		driver.quit();
		Thread.sleep(1000);
	}

}
