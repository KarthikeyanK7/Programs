package testngsele;

public interface Valid_Interface 
{
	void valid() throws InterruptedException;

}
