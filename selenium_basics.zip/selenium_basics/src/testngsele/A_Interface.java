package testngsele;

public interface A_Interface 
{
		void a_interface_valid() throws InterruptedException;
		void a_interface_invalid() throws InterruptedException;

}
