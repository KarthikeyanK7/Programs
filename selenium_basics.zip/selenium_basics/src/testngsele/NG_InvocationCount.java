package testngsele;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;

public class NG_InvocationCount 				
{
	WebDriver driver;

	@Test(invocationCount = 2,invocationTimeOut = 30000)			//invocation count
	public void invocation() throws InterruptedException
	{
		driver.findElement(By.xpath("//input[@id='txt_unam']")).sendKeys("sylix");
		driver.findElement(By.xpath("//input[@id='txt_pass']")).sendKeys("admin");
		driver.findElement(By.xpath("//input[@id='Button3']")).click();
		Thread.sleep(1000);
		System.out.println("invocation count");
		driver.findElement(By.xpath("//a[@id='LinkButton1']")).click();
		
	}
	

	@BeforeClass
	public void beforeClass() 
	{
		System.setProperty("webdriver.chrome.driver","D:\\crmdriver\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.navigate().to("http://brm.tremplintech.in/web_pages/login.aspx");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	}

	@AfterClass
	public void afterClass() throws InterruptedException 
	{
		
		driver.close();
		
	}

}