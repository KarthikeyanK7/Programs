package testngsele;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;

public class NG_Priority 
{
	WebDriver driver;

	@Test(priority = 3)
	public void valid() throws InterruptedException 
	{

		WebElement user = driver.findElement(By.xpath("//input[@id='txt_unam']"));
		user.sendKeys("sylix");
		WebElement pwd = driver.findElement(By.xpath("//input[@id='txt_pass']"));
		pwd.sendKeys("admin");
		WebElement Login = driver.findElement(By.xpath("//input[@id='Button3']"));
		Login.click();
		Thread.sleep(1000);
		WebElement Logout = driver.findElement(By.xpath("//a[@id='LinkButton1']"));
		Logout.click();

	}

	@Test(priority = 2)
	public void invalid() throws InterruptedException 
	{

		WebElement user = driver.findElement(By.xpath("//input[@id='txt_unam']"));
		user.sendKeys("45lix");
		WebElement pwd = driver.findElement(By.xpath("//input[@id='txt_pass']"));
		pwd.sendKeys("123min");
		WebElement Login = driver.findElement(By.xpath("//input[@id='Button3']"));
		Login.click();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);

	}

	@Test(priority = 1)
	public void illegal() throws InterruptedException 
	{

		WebElement user = driver.findElement(By.xpath("//input[@id='txt_unam']"));
		user.sendKeys("$ylix");
		WebElement pwd = driver.findElement(By.xpath("//input[@id='txt_pass']"));
		pwd.sendKeys("@dmin");
		WebElement Login = driver.findElement(By.xpath("//input[@id='Button3']"));
		Login.click();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);

	}

	@Test(enabled = true)
	public void fnull() throws InterruptedException 
	{

		WebElement user = driver.findElement(By.xpath("//input[@id='txt_unam']"));
		user.sendKeys(" ");
		WebElement pwd = driver.findElement(By.xpath("//input[@id='txt_pass']"));
		pwd.sendKeys(" ");
		WebElement Login = driver.findElement(By.xpath("//input[@id='Button3']"));
		Login.click();
		driver.switchTo().alert().accept();
		Thread.sleep(2000);

	}

	@BeforeClass
	public void beforeClass() 
	{
		System.setProperty("webdriver.chrome.driver", "D:\\crmdriver\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://brm.tremplintech.in/web_pages/login.aspx");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.manage().window().maximize();
	}

	@AfterClass
	public void afterClass() throws InterruptedException 
	{
		
		driver.close();
		
	}

}
