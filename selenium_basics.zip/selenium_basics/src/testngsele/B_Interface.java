package testngsele;

public interface B_Interface 
{
	void b_interface_illegal() throws InterruptedException;
	
}
