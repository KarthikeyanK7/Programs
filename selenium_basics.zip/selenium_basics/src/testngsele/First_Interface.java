package testngsele;

public interface First_Interface 
{
	void first_interface_valid() throws InterruptedException;

}
