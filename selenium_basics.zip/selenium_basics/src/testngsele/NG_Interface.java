package testngsele;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class NG_Interface implements First_Interface,Second_Interface 
{

	public WebDriver driver;

	@Test(priority = 11)
	public void ng_interface_illegal() throws InterruptedException 
	{
		driver.findElement(By.xpath("//input[@id='txt_unam']")).sendKeys("@#$$");
		driver.findElement(By.xpath("//input[@id='txt_pass']")).sendKeys("#$%");
		driver.findElement(By.xpath("//input[@id='Button3']")).click();
		System.out.println("I-illegal");
		Thread.sleep(1000);
		driver.switchTo().alert().accept();// 60KB
	}

	@Test(priority = 12)
	public void ng_interface_null() throws InterruptedException 
	{
		driver.findElement(By.xpath("//input[@id='txt_unam']")).sendKeys(" ");
		driver.findElement(By.xpath("//input[@id='txt_pass']")).sendKeys(" ");
		driver.findElement(By.xpath("//input[@id='Button3']")).click();		
		System.out.println("I-null");
		Thread.sleep(1000);
		driver.switchTo().alert().accept();// 60KB
	}
	@Test(priority = 9)
	@Override
	public void first_interface_valid() throws InterruptedException 
	{
		driver.findElement(By.xpath("//input[@id='txt_unam']")).sendKeys("sylix");
		driver.findElement(By.xpath("//input[@id='txt_pass']")).sendKeys("admin");
		driver.findElement(By.xpath("//input[@id='Button3']")).click();
		System.out.println("FI-valid");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//a[@id='LinkButton1']")).click();
	}

	
	@Test(priority = 10)
	@Override
	public void second_interface_invalid() throws InterruptedException 
	{
		driver.findElement(By.xpath("//input[@id='txt_unam']")).sendKeys("sylix12");
		driver.findElement(By.xpath("//input[@id='txt_pass']")).sendKeys("ada5min");
		driver.findElement(By.xpath("//input[@id='Button3']")).click();
		System.out.println("SI-invalid");
		Thread.sleep(1000);
		driver.switchTo().alert().accept();// 60KB
	}
	

	@BeforeClass
	public void beforeClass() throws InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver","D:\\crmdriver\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.navigate().to("http://brm.tremplintech.in/web_pages/login.aspx");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));


	}

	@AfterClass
	public void afterClass() throws InterruptedException
	{
		
		driver.quit();
		Thread.sleep(1000);

	}
}
