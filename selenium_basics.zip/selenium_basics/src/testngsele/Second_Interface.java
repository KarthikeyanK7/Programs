package testngsele;

public interface Second_Interface 
{
	void second_interface_invalid() throws InterruptedException;

}
