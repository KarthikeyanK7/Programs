package testngsele;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Ignore;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;

public class NG_Ignore 
{
	 WebDriver driver;	//global declaration
 @Test
 public void f() throws InterruptedException 
 {
	  driver.findElement(By.xpath("//input[@id='txt_unam']")).sendKeys("sylix");
	  driver.findElement(By.xpath("//input[@id='txt_pass']")).sendKeys("admin");
	  driver.findElement(By.xpath("//input[@id='Button3']")).click();
	  Thread.sleep(1000);
	  System.out.println("not ignored");
	  driver.findElement(By.xpath("//a[@id='LinkButton1']")).click();
	  

 }
 @Ignore
 @Test
 public void fa() throws InterruptedException 
 {
	  driver.findElement(By.xpath("//input[@id='txt_unam']")).sendKeys("sylix");
	  driver.findElement(By.xpath("//input[@id='txt_pass']")).sendKeys("admin");
	  driver.findElement(By.xpath("//input[@id='Button3']")).click();
	  Thread.sleep(3000);
	  System.out.println("ignored");
	  driver.findElement(By.xpath("//a[@id='LinkButton1']")).click();
	  Thread.sleep(1000);

 }
 @BeforeClass
 public void beforeClass() throws InterruptedException 
 {
	  System.setProperty("webdriver.chrome.driver","D:\\crmdriver\\chromedriver.exe");
	  driver = new ChromeDriver();
	  driver.get("http://brm.tremplintech.in/web_pages/login.aspx");
	  driver.manage().window().maximize();
	  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

 }

 @AfterClass
 public void afterClass() 
 {
	  driver.close();
 }

}

