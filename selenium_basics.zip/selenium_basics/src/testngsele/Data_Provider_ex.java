package testngsele;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class Data_Provider_ex 
{
	@Test(dataProvider = "login1")
	public void loginacc(String user,String pass,String OTP,int Gcode)
	{
		System.out.println(user+"   "+pass+"   "+OTP+ "   "+Gcode);
		
	}
	
	
	@DataProvider
	public Object[][] login1()
	{
		return new Object[][]
				{
					{"kathi","kk123","6465",456},
					{"keyan","sf16","65465",645},
					{"admin","fas65","8943",515}			
				};

	}

}
