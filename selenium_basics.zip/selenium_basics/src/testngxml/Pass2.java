package testngxml;

import org.testng.annotations.Test;

public class Pass2 
{

	@Test
	public void testa()
	{
		System.out.println("two");
	}
	
	
}
