package testngxml;

import org.testng.annotations.Test;

public class Pass1 
{

	@Test
	public void testa()
	{
		System.out.println("one");
	}
	
	
}
