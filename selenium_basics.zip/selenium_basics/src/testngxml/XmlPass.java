package testngxml;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;


public class XmlPass 
{
	
	@Test
	@Parameters({"Name","Pass"})
	public void para(String name,String pass) 
	{
		System.out.println("value from the parameter = "+name);
		System.out.println("value from the parameter = "+pass);
	}
	

}
